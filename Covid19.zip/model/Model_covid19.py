############################################################################
## (C)Copyright 2021-2023 Hewlett Packard Enterprise Development LP
## Licensed under the Apache License, Version 2.0 (the "License"); you may
## not use this file except in compliance with the License. You may obtain
## a copy of the License at
##
##    http://www.apache.org/licenses/LICENSE-2.0
##
## Unless required by applicable law or agreed to in writing, software
## distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
## WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
## License for the specific language governing permissions and limitations
## under the License.
############################################################################

import os
import numpy as np
import pandas as pd
import csv
import logging
import tensorflow as tf

from swarmlearning.tf import SwarmCallback


def load_data(path):
    np.random.shuffle(path)
    for col in X.select_dtypes(include='object').columns:
        X[col] = pd.to_numeric(X[col], errors='coerce')
        X[col].fillna(0, inplace=True) 
        
    Y = X.iloc[:, -1:]
    num_records = Y.shape[0]
    X = tf.constant(X.values[:, 0:784])
    X = tf.reshape(X, (num_records, 784, 1))
    #X = tf.reshape(X, (num_records, 28, 28, 1))
    Y = tf.one_hot(Y.values[:, 0:], 2)
    Y = tf.reshape(Y, (num_records, 2))
    return X, Y

# Constants
fileNameList = [
    'test.csv'
  , 'PC1.csv'
  , 'PC1.csv'
  , 'PC3.csv'
]

part = 0
batchSize = 64
defaultMaxEpoch = 100
defaultMinPeers = 2

def main():
  modelName = 'Model_covid19'
  dataDir = os.getenv('DATA_DIR', '/platform/data/')
  scratchDir = os.getenv('SCRATCH_DIR', '/platform/scratch')
  maxEpoch = int(os.getenv('MAX_EPOCHS', str(defaultMaxEpoch)))
  minPeers = int(os.getenv('MIN_PEERS', str(defaultMinPeers)))
  os.makedirs(scratchDir, exist_ok=True)
  print('***** Starting model =', modelName)
  # ================== load test Data =========================
  print('-' * 64)
  fname = fileNameList[part]
  testFile = dataDir + '/' + fname
  print("loading test dataset %s .." % testFile)
  with open(testFile, 'r') as f:
    # first line is the header row so remove it
    testData = np.array(list(csv.reader(f, delimiter=","))[1:], dtype=float)
    print('size of testing Data set : %s' % np.size(testData,0))

  print('-' * 64)
  # ================== Model to train and evaluate =========================
  # Model CNN
def Model(X):
    input = tf.keras.layers.Input(shape=X[0].shape)
    x = tf.keras.layers.Conv1D(32, 3, activation='relu')(input)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.MaxPooling1D(3)(x)
    x = tf.keras.layers.Conv1D(64, 3, activation='relu')(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.MaxPooling1D(3)(x)
    x = tf.keras.layers.Flatten()(x)
    output = tf.keras.layers.Dense(2)(x)
    output = tf.keras.layers.Dropout(.5,input_shape=(2,))(output)
    output = tf.keras.layers.Activation('sigmoid')(output)
    model = tf.keras.models.Model(inputs=[input], outputs=[output])
    return model

    print('Starting training ...')
    X_test, Y_test = load_data(testData)


  # Adding swarm callback
    swarmCallback = SwarmCallback(syncFrequency=128, minPeers=minPeers)

  # Model training
    model = global_model()
    optimizer = tf.keras.optimizers.Adam(learning_rate= 0.01)
    model.fit(
      X
    , Y
    , batch_size=batchSize
    , epochs=maxEpoch
    , validation_data=(X_test, Y_test)
    , shuffle=True
    , callbacks=[swarmCallback]
  )

    print('Training done!')

  # Evaluate
def Evaluation_Function(global_model,X,Y):
    y_predict = global_model.predict(X).argmax(1)
    y_true = np.array(yY).argmax(1)
    acc = tf.keras.metrics.Accuracy()
    acc.update_state(y_true, y_predict)
    acc = acc.result().numpy()
    recall = tf.keras.metrics.Recall()
    recall.update_state(y_true, y_predict)
    recall = recall.result().numpy()
    precision = tf.keras.metrics.Precision()
    precision.update_state(y_true, y_predict)
    precision = precision.result().numpy()
    f_score =  2 * recall * precision / (recall + precision)
    return [acc,recall,precision,f_score]

    scores = Evaluation_Function(X, yY, verbose=1)
    print('*****accuracy:', scores[1])

  # Save
    model_path = os.path.join(scratchDir, modelName)
    model.save(model_path)
    print('Model saved!')

if __name__ == '__main__':
    main()